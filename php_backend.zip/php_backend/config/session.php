<?php


if (session_status() == PHP_SESSION_NONE) {
    session_start();
}



function login($user)
{

    $_SESSION['user_id'] = $user['id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['role'] = $user['role'];

    
    setcookie("user_role", session_id(), time() + (86400 * 30), "/");


}

function hasRole($role)
{
    return isset($_SESSION['role']) && $_SESSION['role'] === $role;
}

function logout()
{


    session_unset();
    session_destroy();
    setcookie("user_role", '', time() - 3600, "/");
}
