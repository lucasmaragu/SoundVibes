<?php

require 'config/session.php';

logout();
header('Location: login.php');
exit();